package dao;

import entity.BureauVote;
import entity.utils.KeyBureauVote;

/**
 * Created by dialal14 on 23/01/17.
 */
public interface BureauVoteDao  extends GenericDao<BureauVote, KeyBureauVote>{
}
